# School Community PWA

A lightweight, cost-optimized school community social media web app built with Next.js, React, Tailwind CSS, and Supabase.

## Features

- **Authentication & Roles**: Email/password auth with admin, verified, and unverified user roles
- **X-Style Feed UI**: Modern Twitter-like interface with posts, media grids, and interactions
- **Progressive Web App**: Installable, offline-capable with service worker caching
- **Cost-Optimized**: Minimal Supabase reads/writes, auto-delete old posts, bottom sheet profiles
- **Admin Panel**: Verification management, announcement creation, content moderation
- **Lightweight Notifications**: Mentions and announcements only

## Setup Instructions

### 1. Supabase Setup

1. Create a new Supabase project at https://supabase.com
2. Go to SQL Editor and run the `database.sql` file to create all tables and policies
3. Go to Storage and create a new public bucket called `media`
4. Get your project URL and anon key from Settings > API

### 2. Storage Bucket

1. Go to Supabase Storage
2. Create a new bucket called `media`
3. Make it **public** (click on the bucket > Settings > Public bucket: ON)

### 3. Environment Variables

The environment variables should already be set in Replit Secrets:

```env
NEXT_PUBLIC_SUPABASE_URL=your_supabase_project_url
NEXT_PUBLIC_SUPABASE_ANON_KEY=your_supabase_anon_key
```

### 4. Create First Admin User

After running the database.sql file, create your first admin user:

1. Sign up with your admin email through the app
2. Go to Supabase SQL Editor and run:

```sql
UPDATE users SET role = 'admin', is_verified = true WHERE email = 'your-admin-email@example.com';
```

Note: The database trigger will automatically create a user profile when you sign up. If for some reason the trigger doesn't fire, the app has fallback logic to create the profile on first login.

## Key Features

### User Roles

- **Unverified**: Can create up to 2 posts, can request verification
- **Verified**: Full posting access, verification expires after 30 days
- **Admin**: Full access, can approve verifications, create announcements, delete content

### Performance Optimizations

- Auto-delete posts older than 24 hours
- Lazy-load all images and videos
- Pagination (20 posts per load)
- Offline caching for last 20 posts
- Bottom sheet profiles (no navigation = fewer reads)
- Service worker caching for media

### PWA Features

- Install prompt on mobile and desktop
- Offline support with cached posts
- Responsive design
- App-like experience

## Project Structure

```
├── app/                    # Next.js pages
│   ├── feed/              # Main feed
│   ├── create/            # Create posts
│   ├── profile/           # User profile
│   ├── admin/             # Admin panel
│   └── announcements/     # Announcements list
├── components/            # React components
│   ├── Navbar.tsx
│   ├── PostItem.tsx
│   ├── CommentItem.tsx
│   ├── BottomSheetProfile.tsx
│   ├── NotificationBell.tsx
│   └── MediaViewer.tsx
├── lib/                   # Utilities
│   └── supabase.ts       # Supabase client
├── public/               # Static assets
│   ├── manifest.json     # PWA manifest
│   ├── sw.js            # Service worker
│   └── offline.html     # Offline fallback
└── database.sql         # Database schema
```

## License

MIT
