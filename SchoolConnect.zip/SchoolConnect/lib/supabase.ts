import { createClient } from '@supabase/supabase-js'

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!

export const supabase = createClient(supabaseUrl, supabaseAnonKey)

export type User = {
  id: string
  email: string
  full_name: string | null
  department: string | null
  level: string | null
  contact_info: string | null
  role: 'admin' | 'verified' | 'unverified'
  is_verified: boolean
  verified_at: string | null
  created_at: string
}

export type Post = {
  id: string
  user_id: string
  content: string
  post_url: string | null
  media_urls: string[] | null
  created_at: string
  user?: User
}

export type Comment = {
  id: string
  post_id: string
  user_id: string
  content: string
  mentioned_user_ids: string[] | null
  created_at: string
  user?: User
}

export type Notification = {
  id: string
  user_id: string
  type: string
  content: string
  read: boolean
  created_at: string
}

export type Announcement = {
  id: string
  admin_id: string
  content: string
  created_at: string
  admin?: User
}

export type VerificationRequest = {
  id: string
  user_id: string
  status: 'pending' | 'approved' | 'rejected'
  created_at: string
  user?: User
}
