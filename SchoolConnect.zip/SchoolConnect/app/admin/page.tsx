'use client'

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { supabase } from '@/lib/supabase'
import type { User, VerificationRequest } from '@/lib/supabase'
import Navbar from '@/components/Navbar'

export default function AdminPage() {
  const [currentUser, setCurrentUser] = useState<User | null>(null)
  const [requests, setRequests] = useState<VerificationRequest[]>([])
  const [announcement, setAnnouncement] = useState('')
  const [loading, setLoading] = useState(false)
  const router = useRouter()

  useEffect(() => {
    checkAuth()
  }, [])

  const checkAuth = async () => {
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) {
      router.push('/auth')
      return
    }

    let { data: userData } = await supabase
      .from('users')
      .select('*')
      .eq('id', user.id)
      .maybeSingle()

    if (!userData) {
      await supabase
        .from('users')
        .insert({
          id: user.id,
          email: user.email || '',
          role: 'unverified',
          is_verified: false
        })
      
      const { data: newUserData } = await supabase
        .from('users')
        .select('*')
        .eq('id', user.id)
        .single()
      
      userData = newUserData
    }

    if (userData?.role !== 'admin') {
      router.push('/feed')
      return
    }

    setCurrentUser(userData)
    await fetchVerificationRequests()
  }

  const fetchVerificationRequests = async () => {
    const { data } = await supabase
      .from('verification_requests')
      .select(`
        *,
        user:users(*)
      `)
      .eq('status', 'pending')
      .order('created_at', { ascending: false })

    if (data) {
      setRequests(data as VerificationRequest[])
    }
  }

  const handleApproveVerification = async (requestId: string, userId: string) => {
    await supabase
      .from('users')
      .update({
        role: 'verified',
        is_verified: true,
        verified_at: new Date().toISOString(),
      })
      .eq('id', userId)

    await supabase
      .from('verification_requests')
      .update({ status: 'approved' })
      .eq('id', requestId)

    await supabase
      .from('notifications')
      .insert({
        user_id: userId,
        type: 'verification',
        content: 'Your verification request has been approved!',
      })

    fetchVerificationRequests()
  }

  const handleRejectVerification = async (requestId: string, userId: string) => {
    await supabase
      .from('verification_requests')
      .update({ status: 'rejected' })
      .eq('id', requestId)

    await supabase
      .from('notifications')
      .insert({
        user_id: userId,
        type: 'verification',
        content: 'Your verification request has been rejected.',
      })

    fetchVerificationRequests()
  }

  const handleCreateAnnouncement = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!currentUser || !announcement.trim()) return

    setLoading(true)

    const { data: announcementData, error: announcementError } = await supabase
      .from('announcements')
      .insert({
        admin_id: currentUser.id,
        content: announcement.trim(),
      })
      .select()
      .single()

    if (!announcementError) {
      const { data: allUsers } = await supabase
        .from('users')
        .select('id')

      if (allUsers) {
        const notifications = allUsers.map(user => ({
          user_id: user.id,
          type: 'announcement',
          content: `New announcement: ${announcement.slice(0, 50)}${announcement.length > 50 ? '...' : ''}`,
        }))

        await supabase
          .from('notifications')
          .insert(notifications)
      }

      setAnnouncement('')
      alert('Announcement created!')
    }

    setLoading(false)
  }

  return (
    <div className="min-h-screen bg-white">
      <Navbar />
      
      <div className="max-w-2xl mx-auto">
        <div className="border-b border-gray-200 px-4 py-4">
          <h1 className="text-xl font-bold">Admin Panel</h1>
        </div>

        <div className="p-4 space-y-6">
          <div>
            <h2 className="text-lg font-bold mb-4">Create Announcement</h2>
            <form onSubmit={handleCreateAnnouncement} className="space-y-4">
              <textarea
                value={announcement}
                onChange={(e) => setAnnouncement(e.target.value)}
                placeholder="Announcement content..."
                className="w-full p-4 border border-gray-300 rounded-lg focus:ring-2 focus:ring-x-blue focus:border-transparent resize-none"
                rows={4}
              />
              <button
                type="submit"
                disabled={loading}
                className="w-full bg-x-blue text-white py-2 rounded-full font-semibold hover:bg-blue-600 disabled:opacity-50"
              >
                {loading ? 'Creating...' : 'Create Announcement'}
              </button>
            </form>
          </div>

          <div>
            <h2 className="text-lg font-bold mb-4">
              Verification Requests ({requests.length})
            </h2>
            {requests.length === 0 ? (
              <p className="text-gray-500 text-center py-8">
                No pending verification requests
              </p>
            ) : (
              <div className="space-y-3">
                {requests.map((request) => (
                  <div
                    key={request.id}
                    className="border border-gray-200 rounded-lg p-4"
                  >
                    <div className="flex items-start justify-between">
                      <div>
                        <p className="font-semibold">
                          {request.user?.full_name || 'Anonymous'}
                        </p>
                        <p className="text-sm text-gray-500">
                          {request.user?.email}
                        </p>
                        {request.user?.department && (
                          <p className="text-sm text-gray-600">
                            {request.user.department} - Level {request.user.level}
                          </p>
                        )}
                        <p className="text-xs text-gray-400 mt-1">
                          Requested: {new Date(request.created_at).toLocaleDateString()}
                        </p>
                      </div>
                      <div className="flex gap-2">
                        <button
                          onClick={() => handleApproveVerification(request.id, request.user_id)}
                          className="px-4 py-2 bg-green-500 text-white rounded-lg hover:bg-green-600 text-sm"
                        >
                          Approve
                        </button>
                        <button
                          onClick={() => handleRejectVerification(request.id, request.user_id)}
                          className="px-4 py-2 bg-red-500 text-white rounded-lg hover:bg-red-600 text-sm"
                        >
                          Reject
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
