'use client'

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { supabase } from '@/lib/supabase'
import type { User } from '@/lib/supabase'
import Navbar from '@/components/Navbar'

export default function CreatePage() {
  const [content, setContent] = useState('')
  const [postUrl, setPostUrl] = useState('')
  const [mediaFiles, setMediaFiles] = useState<File[]>([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [currentUser, setCurrentUser] = useState<User | null>(null)
  const [postCount, setPostCount] = useState(0)
  const router = useRouter()

  useEffect(() => {
    checkAuth()
  }, [])

  const checkAuth = async () => {
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) {
      router.push('/auth')
      return
    }

    let { data: userData } = await supabase
      .from('users')
      .select('*')
      .eq('id', user.id)
      .maybeSingle()

    if (!userData) {
      await supabase
        .from('users')
        .insert({
          id: user.id,
          email: user.email || '',
          role: 'unverified',
          is_verified: false
        })
      
      const { data: newUserData } = await supabase
        .from('users')
        .select('*')
        .eq('id', user.id)
        .single()
      
      userData = newUserData
    }

    if (userData) {
      setCurrentUser(userData)
      
      if (userData.role === 'unverified') {
        const { count } = await supabase
          .from('posts')
          .select('*', { count: 'exact', head: true })
          .eq('user_id', user.id)

        setPostCount(count || 0)
      }
    }
  }

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || [])
    
    if (files.length > 5) {
      setError('Maximum 5 media files allowed')
      return
    }

    const validFiles = files.filter(file => {
      if (file.size > 5 * 1024 * 1024) {
        setError('Each file must be less than 5MB')
        return false
      }
      return true
    })

    setMediaFiles(validFiles)
    setError('')
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    
    if (!currentUser) return

    if (currentUser.role === 'unverified' && postCount >= 2) {
      setError('Unverified users can only create 2 posts. Request verification to post more.')
      return
    }

    if (!content.trim()) {
      setError('Post content is required')
      return
    }

    setLoading(true)
    setError('')

    try {
      const mediaUrls: string[] = []

      for (const file of mediaFiles) {
        const fileExt = file.name.split('.').pop()
        const fileName = `${Math.random()}.${fileExt}`
        const { data, error: uploadError } = await supabase.storage
          .from('media')
          .upload(fileName, file)

        if (uploadError) throw uploadError

        const { data: { publicUrl } } = supabase.storage
          .from('media')
          .getPublicUrl(fileName)

        mediaUrls.push(publicUrl)
      }

      const { error: insertError } = await supabase
        .from('posts')
        .insert({
          user_id: currentUser.id,
          content: content.trim(),
          post_url: postUrl.trim() || null,
          media_urls: mediaUrls.length > 0 ? mediaUrls : null,
        })

      if (insertError) throw insertError

      router.push('/feed')
    } catch (err: any) {
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-white">
      <Navbar />
      
      <div className="max-w-2xl mx-auto">
        <div className="border-b border-gray-200 px-4 py-4">
          <h1 className="text-xl font-bold">Create Post</h1>
        </div>

        {currentUser?.role === 'unverified' && postCount >= 2 && (
          <div className="mx-4 mt-4 p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
            <p className="text-sm text-yellow-800">
              You've reached the posting limit for unverified users (2 posts). Request verification to post more.
            </p>
          </div>
        )}

        <form onSubmit={handleSubmit} className="p-4 space-y-4">
          <div>
            <textarea
              value={content}
              onChange={(e) => setContent(e.target.value)}
              placeholder="What's happening?"
              className="w-full p-4 border border-gray-300 rounded-lg focus:ring-2 focus:ring-x-blue focus:border-transparent resize-none"
              rows={6}
              maxLength={500}
            />
            <p className="text-sm text-gray-500 mt-1">
              {content.length}/500 characters
            </p>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Link (optional)
            </label>
            <input
              type="url"
              value={postUrl}
              onChange={(e) => setPostUrl(e.target.value)}
              placeholder="https://example.com"
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-x-blue focus:border-transparent"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Media (up to 5 files, max 5MB each)
            </label>
            <input
              type="file"
              onChange={handleFileChange}
              accept="image/*,video/*"
              multiple
              className="w-full px-4 py-2 border border-gray-300 rounded-lg"
            />
            {mediaFiles.length > 0 && (
              <p className="text-sm text-gray-500 mt-1">
                {mediaFiles.length} file(s) selected
              </p>
            )}
          </div>

          {error && (
            <div className="text-red-500 text-sm">{error}</div>
          )}

          <button
            type="submit"
            disabled={loading || (currentUser?.role === 'unverified' && postCount >= 2)}
            className="w-full bg-x-blue text-white py-3 rounded-full font-semibold hover:bg-blue-600 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {loading ? 'Posting...' : 'Post'}
          </button>
        </form>
      </div>
    </div>
  )
}
