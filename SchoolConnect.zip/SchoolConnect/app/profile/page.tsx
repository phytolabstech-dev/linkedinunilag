'use client'

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { supabase } from '@/lib/supabase'
import type { User } from '@/lib/supabase'
import Navbar from '@/components/Navbar'

export default function ProfilePage() {
  const [user, setUser] = useState<User | null>(null)
  const [fullName, setFullName] = useState('')
  const [department, setDepartment] = useState('')
  const [level, setLevel] = useState('')
  const [contactInfo, setContactInfo] = useState('')
  const [loading, setLoading] = useState(false)
  const [success, setSuccess] = useState(false)
  const [canRequestVerification, setCanRequestVerification] = useState(false)
  const router = useRouter()

  useEffect(() => {
    checkAuth()
  }, [])

  const checkAuth = async () => {
    const { data: { user: authUser } } = await supabase.auth.getUser()
    if (!authUser) {
      router.push('/auth')
      return
    }

    let { data: userData } = await supabase
      .from('users')
      .select('*')
      .eq('id', authUser.id)
      .maybeSingle()

    if (!userData) {
      await supabase
        .from('users')
        .insert({
          id: authUser.id,
          email: authUser.email || '',
          role: 'unverified',
          is_verified: false
        })
      
      const { data: newUserData } = await supabase
        .from('users')
        .select('*')
        .eq('id', authUser.id)
        .single()
      
      userData = newUserData
    }

    if (userData) {
      setUser(userData)
      setFullName(userData.full_name || '')
      setDepartment(userData.department || '')
      setLevel(userData.level || '')
      setContactInfo(userData.contact_info || '')

      if (userData.role === 'unverified') {
        const { data: existingRequest } = await supabase
          .from('verification_requests')
          .select('*')
          .eq('user_id', authUser.id)
          .eq('status', 'pending')
          .maybeSingle()

        setCanRequestVerification(!existingRequest)
      }
    }
  }

  const handleUpdateProfile = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!user) return

    setLoading(true)

    const { error } = await supabase
      .from('users')
      .update({
        full_name: fullName,
        department: department,
        level: level,
        contact_info: contactInfo,
      })
      .eq('id', user.id)

    setLoading(false)

    if (!error) {
      setSuccess(true)
      setTimeout(() => setSuccess(false), 3000)
    }
  }

  const handleRequestVerification = async () => {
    if (!user) return

    const { error } = await supabase
      .from('verification_requests')
      .insert({
        user_id: user.id,
        status: 'pending',
      })

    if (!error) {
      setCanRequestVerification(false)
      alert('Verification request submitted!')
    }
  }

  const getRoleLabel = () => {
    if (!user) return ''
    if (user.role === 'admin') return 'Admin'
    if (user.is_verified) return 'Verified user'
    return 'Unverified'
  }

  return (
    <div className="min-h-screen bg-white">
      <Navbar />
      
      <div className="max-w-2xl mx-auto">
        <div className="border-b border-gray-200 px-4 py-4">
          <h1 className="text-xl font-bold">Profile</h1>
        </div>

        <div className="p-4">
          <div className="flex items-center gap-4 mb-6">
            <div className="w-20 h-20 bg-gradient-to-br from-x-blue to-blue-600 rounded-full flex items-center justify-center text-white text-3xl font-bold">
              {fullName?.[0]?.toUpperCase() || user?.email[0].toUpperCase() || 'A'}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-2xl font-bold">{fullName || 'Anonymous'}</h2>
                {user?.is_verified && (
                  <svg className="w-6 h-6 text-x-blue" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                )}
              </div>
              <p className="text-gray-500">{getRoleLabel()}</p>
              <p className="text-sm text-gray-500">{user?.email}</p>
            </div>
          </div>

          {user?.role === 'unverified' && canRequestVerification && (
            <button
              onClick={handleRequestVerification}
              className="mb-6 w-full bg-green-500 text-white py-2 rounded-lg font-semibold hover:bg-green-600"
            >
              Request Verification
            </button>
          )}

          {success && (
            <div className="mb-4 p-3 bg-green-50 text-green-700 rounded-lg">
              Profile updated successfully!
            </div>
          )}

          <form onSubmit={handleUpdateProfile} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Full Name
              </label>
              <input
                type="text"
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-x-blue focus:border-transparent"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Department
              </label>
              <input
                type="text"
                value={department}
                onChange={(e) => setDepartment(e.target.value)}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-x-blue focus:border-transparent"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Level
              </label>
              <input
                type="text"
                value={level}
                onChange={(e) => setLevel(e.target.value)}
                placeholder="e.g., 100, 200, 300, 400"
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-x-blue focus:border-transparent"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Contact Info
              </label>
              <input
                type="text"
                value={contactInfo}
                onChange={(e) => setContactInfo(e.target.value)}
                placeholder="Phone number or link"
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-x-blue focus:border-transparent"
              />
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full bg-x-blue text-white py-3 rounded-full font-semibold hover:bg-blue-600 disabled:opacity-50"
            >
              {loading ? 'Saving...' : 'Save Profile'}
            </button>
          </form>
        </div>
      </div>
    </div>
  )
}
