'use client'

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { supabase } from '@/lib/supabase'
import type { Announcement } from '@/lib/supabase'
import Navbar from '@/components/Navbar'

export default function AnnouncementsPage() {
  const [announcements, setAnnouncements] = useState<Announcement[]>([])
  const [loading, setLoading] = useState(true)
  const router = useRouter()

  useEffect(() => {
    checkAuth()
  }, [])

  const checkAuth = async () => {
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) {
      router.push('/auth')
      return
    }

    await fetchAnnouncements()
  }

  const fetchAnnouncements = async () => {
    setLoading(true)
    
    const { data } = await supabase
      .from('announcements')
      .select(`
        *,
        admin:users(*)
      `)
      .order('created_at', { ascending: false })

    if (data) {
      setAnnouncements(data as Announcement[])
    }
    
    setLoading(false)
  }

  const formatDate = (timestamp: string) => {
    const date = new Date(timestamp)
    return date.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    })
  }

  return (
    <div className="min-h-screen bg-white">
      <Navbar />
      
      <div className="max-w-2xl mx-auto">
        <div className="border-b border-gray-200 px-4 py-4">
          <h1 className="text-xl font-bold">Announcements</h1>
        </div>

        {loading ? (
          <div className="p-8 text-center text-gray-500">
            Loading announcements...
          </div>
        ) : announcements.length === 0 ? (
          <div className="p-8 text-center text-gray-500">
            No announcements yet
          </div>
        ) : (
          <div className="p-4 space-y-4">
            {announcements.map((announcement) => (
              <div
                key={announcement.id}
                className="border border-gray-200 rounded-lg p-4 bg-blue-50"
              >
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 bg-gradient-to-br from-x-blue to-blue-600 rounded-full flex items-center justify-center text-white font-semibold flex-shrink-0">
                    {announcement.admin?.full_name?.[0]?.toUpperCase() || 'A'}
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="font-bold">
                        {announcement.admin?.full_name || 'Admin'}
                      </span>
                      <svg className="w-4 h-4 text-x-blue" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                      </svg>
                      <span className="text-sm text-gray-500">· Admin</span>
                    </div>
                    <p className="text-gray-800 mb-2">{announcement.content}</p>
                    <p className="text-xs text-gray-500">
                      {formatDate(announcement.created_at)}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
