'use client'

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { supabase } from '@/lib/supabase'
import type { Post, User } from '@/lib/supabase'
import Navbar from '@/components/Navbar'
import PostItem from '@/components/PostItem'

export default function FeedPage() {
  const [posts, setPosts] = useState<Post[]>([])
  const [loading, setLoading] = useState(true)
  const [currentUser, setCurrentUser] = useState<User | null>(null)
  const router = useRouter()

  useEffect(() => {
    checkAuth()
  }, [])

  const checkAuth = async () => {
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) {
      router.push('/auth')
      return
    }

    const { data: userData, error } = await supabase
      .from('users')
      .select('*')
      .eq('id', user.id)
      .maybeSingle()

    if (error) {
      console.error('Error fetching user data:', error)
      return
    }

    if (!userData) {
      await supabase
        .from('users')
        .insert({
          id: user.id,
          email: user.email || '',
          role: 'unverified',
          is_verified: false
        })
      
      const { data: newUserData } = await supabase
        .from('users')
        .select('*')
        .eq('id', user.id)
        .single()
      
      if (newUserData) {
        setCurrentUser(newUserData)
      }
    } else {
      setCurrentUser(userData)
    }

    await fetchPosts()
  }

  const fetchPosts = async () => {
    setLoading(true)
    
    const { data, error } = await supabase
      .from('posts')
      .select(`
        *,
        user:users(*)
      `)
      .order('created_at', { ascending: false })
      .limit(20)

    if (data) {
      setPosts(data as Post[])
    }
    
    setLoading(false)
  }

  const handleDeletePost = async (postId: string) => {
    const { error } = await supabase
      .from('posts')
      .delete()
      .eq('id', postId)

    if (!error) {
      setPosts(posts.filter(p => p.id !== postId))
    }
  }

  return (
    <div className="min-h-screen bg-white">
      <Navbar />
      
      <div className="max-w-2xl mx-auto">
        <div className="border-b border-gray-200 px-4 py-4">
          <h1 className="text-xl font-bold">Feed</h1>
        </div>

        {loading ? (
          <div className="p-8 text-center text-gray-500">
            Loading posts...
          </div>
        ) : posts.length === 0 ? (
          <div className="p-8 text-center text-gray-500">
            No posts yet. Create the first one!
          </div>
        ) : (
          <div>
            {posts.map((post) => (
              <PostItem
                key={post.id}
                post={post}
                onDelete={currentUser?.role === 'admin' ? handleDeletePost : undefined}
                isAdmin={currentUser?.role === 'admin'}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
