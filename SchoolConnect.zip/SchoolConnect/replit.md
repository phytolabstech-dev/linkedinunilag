# School Community PWA - Replit Project

## Overview
A lightweight, cost-optimized school community social media Progressive Web App (PWA) built with Next.js 14, React 18, Tailwind CSS, and Supabase. Features an X-style UI, role-based authentication, offline caching, and strict performance optimizations for minimal database reads/writes.

## Tech Stack
- **Frontend**: Next.js 14 (App Router), React 18, TypeScript, Tailwind CSS
- **Backend**: Supabase (PostgreSQL, Auth, Storage)
- **PWA**: Service Worker with offline caching, manifest.json

## Project Structure
```
├── app/                     # Next.js app directory
│   ├── auth/               # Authentication page
│   ├── feed/               # Main feed page
│   ├── create/             # Post creation page
│   ├── profile/            # User profile page
│   ├── admin/              # Admin panel
│   ├── announcements/      # Announcements list
│   ├── layout.tsx          # Root layout
│   ├── page.tsx            # Home page (redirects)
│   └── globals.css         # Global styles
├── components/             # React components
│   ├── Navbar.tsx          # Navigation bar
│   ├── PostItem.tsx        # Post display component (X-style UI)
│   ├── CommentItem.tsx     # Comment display component
│   ├── BottomSheetProfile.tsx  # User profile bottom sheet
│   ├── NotificationBell.tsx    # Notification dropdown
│   └── MediaViewer.tsx     # Full-screen media viewer
├── lib/
│   └── supabase.ts         # Supabase client & TypeScript types
├── public/
│   ├── manifest.json       # PWA manifest
│   ├── sw.js              # Service worker
│   └── offline.html       # Offline fallback page
├── database.sql           # Supabase schema & RLS policies
└── README.md             # Setup instructions
```

## Key Features

### Authentication & Roles
- Email/password authentication via Supabase Auth
- Three user roles: admin, verified, unverified
- Verified status expires after 30 days (except for admins)
- Blue verification checkmark for verified users

### X-Style Feed UI
- Exact modern Twitter/X feed layout
- Avatar, name, verified badge, timestamp inline
- Multi-media grid layouts (1-5 items) with aspect-ratio preservation
- Full-screen media viewer modal
- Action buttons: reply, repost, like, share
- Thin grey dividers between posts

### Performance Optimizations
- Auto-delete posts older than 24 hours on feed load
- Lazy-load all images and videos
- Pagination: 20 posts per fetch
- Bottom sheet profiles (no navigation = fewer Supabase reads)
- Offline caching for last 20 posts + media
- Unverified users limited to 2 posts max

### Admin Features
- Approve/reject verification requests
- Create announcements (notifies all users)
- Delete any post or comment
- View pending verification requests

### PWA Capabilities
- Installable on mobile and desktop
- Service worker with caching strategy
- Offline fallback page
- Cached posts and media for offline viewing

## Database Schema

### Tables
- `users`: User profiles with role, verification status
- `posts`: User posts with content, URL, media
- `comments`: Single-level comments with @mentions
- `notifications`: Lightweight notifications (mentions & announcements only)
- `announcements`: Admin announcements
- `verification_requests`: Verification request tracking

### Row Level Security (RLS)
All tables have RLS enabled with appropriate policies for role-based access control.

## Environment Variables Required
```
NEXT_PUBLIC_SUPABASE_URL=your_supabase_url
NEXT_PUBLIC_SUPABASE_ANON_KEY=your_supabase_anon_key
```

## Setup Checklist
1. ✅ Install Node.js and npm dependencies
2. ⏳ Set up Supabase project and run database.sql
3. ⏳ Configure environment variables
4. ⏳ Create media storage bucket in Supabase
5. ⏳ Create first admin user via SQL
6. ⏳ Test PWA installation and offline functionality

## Recent Changes
- 2025-11-02: Initial project scaffolding complete
- Created all pages, components, and PWA files
- Set up Next.js 14 with TypeScript and Tailwind CSS
- Configured database schema with RLS policies

## User Preferences
- Focus on cost optimization and minimal Supabase usage
- X-style UI design matching modern Twitter/X
- PWA with offline capabilities
- No nested comments (single-level only)
- Lightweight notifications (mentions and announcements only)
