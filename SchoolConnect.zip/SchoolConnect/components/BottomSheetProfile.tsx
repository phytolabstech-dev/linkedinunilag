'use client'

import { useEffect, useRef } from 'react'
import type { User } from '@/lib/supabase'

interface BottomSheetProfileProps {
  user: User
  onClose: () => void
}

export default function BottomSheetProfile({ user, onClose }: BottomSheetProfileProps) {
  const sheetRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (sheetRef.current && !sheetRef.current.contains(event.target as Node)) {
        onClose()
      }
    }

    document.addEventListener('mousedown', handleClickOutside)
    return () => document.removeEventListener('mousedown', handleClickOutside)
  }, [onClose])

  const getRoleLabel = () => {
    if (user.role === 'admin') return 'Admin'
    if (user.is_verified) return 'Verified user'
    return 'Unverified'
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-end justify-center z-50 sm:items-center">
      <div
        ref={sheetRef}
        className="bg-white rounded-t-2xl sm:rounded-2xl w-full sm:w-96 max-h-[80vh] overflow-y-auto p-6 animate-slide-up"
      >
        <div className="flex justify-between items-start mb-4">
          <div className="flex items-center gap-3">
            <div className="w-16 h-16 bg-gradient-to-br from-x-blue to-blue-600 rounded-full flex items-center justify-center text-white text-2xl font-bold">
              {user.full_name?.[0]?.toUpperCase() || user.email[0].toUpperCase()}
            </div>
            <div>
              <div className="flex items-center gap-1">
                <h2 className="font-bold text-lg">{user.full_name || 'Anonymous'}</h2>
                {user.is_verified && (
                  <svg className="w-5 h-5 text-x-blue" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                )}
              </div>
              <p className="text-sm text-gray-500">{getRoleLabel()}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-gray-500 hover:text-gray-700"
          >
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        <div className="space-y-3">
          {user.department && (
            <div>
              <p className="text-sm text-gray-500">Department</p>
              <p className="font-medium">{user.department}</p>
            </div>
          )}
          
          {user.level && (
            <div>
              <p className="text-sm text-gray-500">Level</p>
              <p className="font-medium">{user.level}</p>
            </div>
          )}
          
          {user.contact_info && (
            <div>
              <p className="text-sm text-gray-500">Contact</p>
              <a
                href={user.contact_info.startsWith('http') ? user.contact_info : `tel:${user.contact_info}`}
                className="font-medium text-x-blue hover:underline"
                target="_blank"
                rel="noopener noreferrer"
              >
                {user.contact_info}
              </a>
            </div>
          )}

          <div>
            <p className="text-sm text-gray-500">Email</p>
            <p className="font-medium">{user.email}</p>
          </div>
        </div>
      </div>
    </div>
  )
}
