'use client'

import { useState } from 'react'
import type { Comment } from '@/lib/supabase'
import BottomSheetProfile from './BottomSheetProfile'

interface CommentItemProps {
  comment: Comment
  onDelete?: (id: string) => void
  isAdmin?: boolean
}

export default function CommentItem({ comment, onDelete, isAdmin }: CommentItemProps) {
  const [showProfile, setShowProfile] = useState(false)

  const formatTimestamp = (timestamp: string) => {
    const date = new Date(timestamp)
    const now = new Date()
    const diff = now.getTime() - date.getTime()
    const hours = Math.floor(diff / (1000 * 60 * 60))
    
    if (hours < 1) return `${Math.floor(diff / (1000 * 60))}m`
    if (hours < 24) return `${hours}h`
    return date.toLocaleDateString()
  }

  return (
    <>
      <div className="border-b border-gray-100 px-4 py-3 hover:bg-gray-50">
        <div className="flex gap-3">
          <div 
            className="flex-shrink-0 cursor-pointer"
            onClick={() => setShowProfile(true)}
          >
            <div className="w-8 h-8 bg-gradient-to-br from-x-blue to-blue-600 rounded-full flex items-center justify-center text-white text-sm font-semibold">
              {comment.user?.full_name?.[0]?.toUpperCase() || comment.user?.email[0].toUpperCase() || 'A'}
            </div>
          </div>

          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-1 flex-wrap">
              <span 
                className="font-bold text-sm hover:underline cursor-pointer"
                onClick={() => setShowProfile(true)}
              >
                {comment.user?.full_name || 'Anonymous'}
              </span>
              {comment.user?.is_verified && (
                <svg className="w-3.5 h-3.5 text-x-blue" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              )}
              <span className="text-gray-500 text-xs">
                · {formatTimestamp(comment.created_at)}
              </span>
              {(isAdmin || onDelete) && (
                <button 
                  onClick={() => onDelete?.(comment.id)}
                  className="ml-auto text-red-500 hover:text-red-700 text-xs"
                >
                  Delete
                </button>
              )}
            </div>

            <div className="mt-1 text-sm break-words">
              {comment.content}
            </div>
          </div>
        </div>
      </div>

      {showProfile && comment.user && (
        <BottomSheetProfile
          user={comment.user}
          onClose={() => setShowProfile(false)}
        />
      )}
    </>
  )
}
