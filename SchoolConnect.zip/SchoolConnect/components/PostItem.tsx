'use client'

import { useState } from 'react'
import type { Post, User } from '@/lib/supabase'
import BottomSheetProfile from './BottomSheetProfile'
import MediaViewer from './MediaViewer'

interface PostItemProps {
  post: Post
  onDelete?: (id: string) => void
  isAdmin?: boolean
}

export default function PostItem({ post, onDelete, isAdmin }: PostItemProps) {
  const [showProfile, setShowProfile] = useState(false)
  const [showMediaViewer, setShowMediaViewer] = useState(false)
  const [selectedMediaIndex, setSelectedMediaIndex] = useState(0)

  const formatTimestamp = (timestamp: string) => {
    const date = new Date(timestamp)
    const now = new Date()
    const diff = now.getTime() - date.getTime()
    const hours = Math.floor(diff / (1000 * 60 * 60))
    
    if (hours < 1) return `${Math.floor(diff / (1000 * 60))}m`
    if (hours < 24) return `${hours}h`
    return date.toLocaleDateString()
  }

  const renderMediaGrid = () => {
    if (!post.media_urls || post.media_urls.length === 0) return null

    const mediaCount = post.media_urls.length

    if (mediaCount === 1) {
      return (
        <div 
          className="mt-3 rounded-2xl overflow-hidden cursor-pointer"
          onClick={() => {
            setSelectedMediaIndex(0)
            setShowMediaViewer(true)
          }}
        >
          {post.media_urls[0].match(/\.(mp4|webm|ogg)$/i) ? (
            <video 
              src={post.media_urls[0]} 
              className="w-full max-h-96 object-contain bg-black"
              controls
            />
          ) : (
            <img 
              src={post.media_urls[0]} 
              alt="Post media" 
              className="w-full max-h-96 object-contain bg-gray-100"
              loading="lazy"
            />
          )}
        </div>
      )
    }

    if (mediaCount === 2) {
      return (
        <div className="mt-3 grid grid-cols-2 gap-0.5 rounded-2xl overflow-hidden">
          {post.media_urls.map((url, idx) => (
            <div 
              key={idx}
              className="cursor-pointer"
              onClick={() => {
                setSelectedMediaIndex(idx)
                setShowMediaViewer(true)
              }}
            >
              {url.match(/\.(mp4|webm|ogg)$/i) ? (
                <video src={url} className="w-full h-64 object-cover" />
              ) : (
                <img src={url} alt={`Media ${idx + 1}`} className="w-full h-64 object-cover" loading="lazy" />
              )}
            </div>
          ))}
        </div>
      )
    }

    if (mediaCount === 3) {
      return (
        <div className="mt-3 grid grid-cols-2 gap-0.5 rounded-2xl overflow-hidden">
          <div 
            className="col-span-2 cursor-pointer"
            onClick={() => {
              setSelectedMediaIndex(0)
              setShowMediaViewer(true)
            }}
          >
            {post.media_urls[0].match(/\.(mp4|webm|ogg)$/i) ? (
              <video src={post.media_urls[0]} className="w-full h-64 object-cover" />
            ) : (
              <img src={post.media_urls[0]} alt="Media 1" className="w-full h-64 object-cover" loading="lazy" />
            )}
          </div>
          {post.media_urls.slice(1).map((url, idx) => (
            <div 
              key={idx + 1}
              className="cursor-pointer"
              onClick={() => {
                setSelectedMediaIndex(idx + 1)
                setShowMediaViewer(true)
              }}
            >
              {url.match(/\.(mp4|webm|ogg)$/i) ? (
                <video src={url} className="w-full h-48 object-cover" />
              ) : (
                <img src={url} alt={`Media ${idx + 2}`} className="w-full h-48 object-cover" loading="lazy" />
              )}
            </div>
          ))}
        </div>
      )
    }

    if (mediaCount === 4) {
      return (
        <div className="mt-3 grid grid-cols-2 gap-0.5 rounded-2xl overflow-hidden">
          {post.media_urls.map((url, idx) => (
            <div 
              key={idx}
              className="cursor-pointer"
              onClick={() => {
                setSelectedMediaIndex(idx)
                setShowMediaViewer(true)
              }}
            >
              {url.match(/\.(mp4|webm|ogg)$/i) ? (
                <video src={url} className="w-full h-48 object-cover" />
              ) : (
                <img src={url} alt={`Media ${idx + 1}`} className="w-full h-48 object-cover" loading="lazy" />
              )}
            </div>
          ))}
        </div>
      )
    }

    if (mediaCount === 5) {
      return (
        <div className="mt-3 grid grid-cols-2 gap-0.5 rounded-2xl overflow-hidden">
          {post.media_urls.slice(0, 4).map((url, idx) => (
            <div 
              key={idx}
              className={`cursor-pointer ${idx === 3 ? 'relative' : ''}`}
              onClick={() => {
                setSelectedMediaIndex(idx)
                setShowMediaViewer(true)
              }}
            >
              {url.match(/\.(mp4|webm|ogg)$/i) ? (
                <video src={url} className="w-full h-48 object-cover" />
              ) : (
                <img src={url} alt={`Media ${idx + 1}`} className="w-full h-48 object-cover" loading="lazy" />
              )}
              {idx === 3 && (
                <div className="absolute inset-0 bg-black bg-opacity-60 flex items-center justify-center text-white text-3xl font-bold">
                  +1
                </div>
              )}
            </div>
          ))}
        </div>
      )
    }

    return null
  }

  return (
    <>
      <div className="border-b border-gray-200 px-4 py-3 hover:bg-gray-50">
        <div className="flex gap-3">
          <div 
            className="flex-shrink-0 cursor-pointer"
            onClick={() => setShowProfile(true)}
          >
            <div className="w-10 h-10 bg-gradient-to-br from-x-blue to-blue-600 rounded-full flex items-center justify-center text-white font-semibold">
              {post.user?.full_name?.[0]?.toUpperCase() || post.user?.email[0].toUpperCase() || 'A'}
            </div>
          </div>

          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-1 flex-wrap">
              <span 
                className="font-bold hover:underline cursor-pointer"
                onClick={() => setShowProfile(true)}
              >
                {post.user?.full_name || 'Anonymous'}
              </span>
              {post.user?.is_verified && (
                <svg className="w-4 h-4 text-x-blue" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              )}
              <span className="text-gray-500 text-sm">
                · {formatTimestamp(post.created_at)}
              </span>
            </div>

            <div className="mt-1 text-sm sm:text-base break-words">
              {post.content}
            </div>

            {post.post_url && (
              <a
                href={post.post_url}
                target="_blank"
                rel="noopener noreferrer"
                className="mt-2 inline-block text-x-blue hover:underline text-sm"
              >
                {post.post_url}
              </a>
            )}

            {renderMediaGrid()}

            <div className="mt-3 flex items-center gap-8 text-gray-500">
              <button className="flex items-center gap-2 hover:text-x-blue group">
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
                </svg>
              </button>
              
              <button className="flex items-center gap-2 hover:text-green-500 group">
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
                </svg>
              </button>
              
              <button className="flex items-center gap-2 hover:text-red-500 group">
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
                </svg>
              </button>
              
              <button className="flex items-center gap-2 hover:text-x-blue group">
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.368 2.684 3 3 0 00-5.368-2.684z" />
                </svg>
              </button>

              {(isAdmin || onDelete) && (
                <button 
                  onClick={() => onDelete?.(post.id)}
                  className="ml-auto text-red-500 hover:text-red-700"
                >
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                  </svg>
                </button>
              )}
            </div>
          </div>
        </div>
      </div>

      {showProfile && post.user && (
        <BottomSheetProfile
          user={post.user}
          onClose={() => setShowProfile(false)}
        />
      )}

      {showMediaViewer && post.media_urls && (
        <MediaViewer
          mediaUrls={post.media_urls}
          initialIndex={selectedMediaIndex}
          onClose={() => setShowMediaViewer(false)}
        />
      )}
    </>
  )
}
