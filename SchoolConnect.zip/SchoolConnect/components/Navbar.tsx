'use client'

import Link from 'next/link'
import { usePathname, useRouter } from 'next/navigation'
import { supabase } from '@/lib/supabase'
import NotificationBell from './NotificationBell'

export default function Navbar() {
  const pathname = usePathname()
  const router = useRouter()

  const handleSignOut = async () => {
    await supabase.auth.signOut()
    router.push('/auth')
  }

  const isActive = (path: string) => pathname === path

  return (
    <nav className="sticky top-0 bg-white border-b border-gray-200 z-50">
      <div className="max-w-2xl mx-auto px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-6">
          <Link 
            href="/feed" 
            className={`font-semibold ${isActive('/feed') ? 'text-x-blue' : 'text-gray-700 hover:text-x-blue'}`}
          >
            Feed
          </Link>
          <Link 
            href="/create" 
            className={`font-semibold ${isActive('/create') ? 'text-x-blue' : 'text-gray-700 hover:text-x-blue'}`}
          >
            Create
          </Link>
          <Link 
            href="/announcements" 
            className={`font-semibold ${isActive('/announcements') ? 'text-x-blue' : 'text-gray-700 hover:text-x-blue'}`}
          >
            Announcements
          </Link>
          <Link 
            href="/profile" 
            className={`font-semibold ${isActive('/profile') ? 'text-x-blue' : 'text-gray-700 hover:text-x-blue'}`}
          >
            Profile
          </Link>
          <Link 
            href="/admin" 
            className={`font-semibold ${isActive('/admin') ? 'text-x-blue' : 'text-gray-700 hover:text-x-blue'}`}
          >
            Admin
          </Link>
        </div>
        
        <div className="flex items-center gap-4">
          <NotificationBell />
          <button
            onClick={handleSignOut}
            className="text-sm text-gray-600 hover:text-gray-900"
          >
            Sign Out
          </button>
        </div>
      </div>
    </nav>
  )
}
